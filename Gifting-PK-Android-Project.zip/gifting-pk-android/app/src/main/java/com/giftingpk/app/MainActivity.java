package com.giftingpk.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int gold = Color.rgb(232, 185, 67);
    private final int black = Color.rgb(13, 13, 17);
    private final int panel = Color.rgb(29, 29, 36);
    private int coins = 500;
    private LinearLayout root;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private void addButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(gold);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        root.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }
    private void header(String title) {
        TextView h = text(title, 27, gold, true);
        h.setGravity(Gravity.CENTER);
        h.setPadding(0, 20, 0, 12);
        root.addView(h);
    }
    private void base() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 12, 20, 24);
        root.setBackgroundColor(black);
        scroll.addView(root);
        setContentView(scroll);
    }
    private void showHome() {
        base();
        header("✦ GIFTING PK ✦");
        TextView sub = text("VOICE • FRIENDS • GIFTS", 13, Color.LTGRAY, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        TextView wallet = text("🪙  Free demo coins: " + coins, 18, Color.WHITE, true);
        wallet.setPadding(14, 18, 14, 18);
        wallet.setBackgroundColor(panel);
        root.addView(wallet);
        addButton("🎙  Public Voice Rooms", () -> showRooms());
        addButton("🔒  Private Room (demo)", () -> info("Private room", "Private-room UI demo. Online rooms need a secure backend."));
        addButton("🎁  Send a Gift (demo)", () -> showGifts());
        addButton("👑  VIP Membership", () -> info("VIP Membership", "VIP preview only. No payment is taken in this prototype."));
        addButton("🎮  Mini Game", () -> showGame());
        TextView note = text("\nPrototype version 1.0\nVoice chat, online multiplayer, account login and real payments are not connected yet.", 13, Color.LTGRAY, false);
        root.addView(note);
    }
    private void showRooms() {
        base(); header("PUBLIC ROOMS");
        addButton("🎤  Room 001  •  Chill & Chat", () -> showRoom("Chill & Chat"));
        addButton("🎶  Room 002  •  Music Lounge", () -> showRoom("Music Lounge"));
        addButton("💛  Room 003  •  Friends Zone", () -> showRoom("Friends Zone"));
        addButton("← Back to Home", () -> showHome());
    }
    private void showRoom(String name) {
        base(); header(name);
        TextView t = text("Choose a mic seat (visual demo)", 16, Color.WHITE, true);
        root.addView(t);
        for (int i=1;i<=8;i++) {
            final int seat=i;
            addButton("🎙  Seat " + i + (i==1 ? "  •  Host" : "  •  Empty"), () ->
                info("Mic Seat " + seat, "Seat selection is a demo. Real-time voice requires a voice server/SDK."));
        }
        addButton("🎁 Send Gift", () -> showGifts());
        addButton("← Back to Rooms", () -> showRooms());
    }
    private void showGifts() {
        base(); header("GIFT SHOP");
        addButton("🌹 Rose  •  10 coins", () -> gift("Rose",10));
        addButton("💖 Heart  •  50 coins", () -> gift("Heart",50));
        addButton("👑 Crown  •  100 coins", () -> gift("Crown",100));
        addButton("✨ Star  •  25 coins", () -> gift("Star",25));
        addButton("← Back", () -> showHome());
    }
    private void gift(String name, int cost) {
        if (coins < cost) { info("Not enough coins", "Demo wallet mein coins kam hain."); return; }
        coins -= cost;
        info("Gift sent (demo)", name + " selected. Remaining demo coins: " + coins);
    }
    private void showGame() {
        base(); header("LUCKY NUMBER");
        TextView t = text("Tap below to try a simple number game.", 16, Color.WHITE, false);
        root.addView(t);
        addButton("🎲 Try your luck", () -> {
            int n = (int)(Math.random()*6)+1;
            info("You got " + n, n==6 ? "Nice! Demo reward: 20 coins." : "Good try! Play again.");
            if (n==6) coins += 20;
        });
        addButton("← Back", () -> showHome());
    }
    private void info(String title, String msg) {
        new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(msg)
            .setPositiveButton("OK", (d,w) -> {}).show();
    }
}
